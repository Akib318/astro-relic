import * as THREE from 'three';
import { store } from '../../state/store';
import { audio } from '../audio';
import { makeStarfield, makeCanvasTexture, type Scene } from '../utils';
import { CINEMATIC_BEATS } from '../../data/content';

const DURATION = 14; // seconds

export class MarsCinematicScene implements Scene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private mars: THREE.Mesh;
  private stars = makeStarfield(4000, 700);
  private craft: THREE.Group;
  private dust: THREE.Points;
  private entryLight: THREE.PointLight;
  private time = 0;
  private beatIdx = 0;
  private done = false;

  constructor(renderer: THREE.WebGLRenderer) {
    this.renderer = renderer;
    this.camera = new THREE.PerspectiveCamera(55, innerWidth / innerHeight, 0.1, 2000);
    this.scene.background = new THREE.Color(0x050308);
    this.scene.add(this.stars);

    // Mars
    const marsTex = makeCanvasTexture(1024, (ctx, s) => {
      ctx.fillStyle = '#b4532f';
      ctx.fillRect(0, 0, s, s);
      for (let i = 0; i < 400; i++) {
        const x = Math.random() * s;
        const y = Math.random() * s;
        const r = 8 + Math.random() * 70;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        const dark = Math.random() > 0.5;
        g.addColorStop(0, dark ? 'rgba(90,35,20,0.35)' : 'rgba(220,150,110,0.25)');
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      // polar caps
      ctx.fillStyle = 'rgba(245,238,228,0.95)';
      ctx.fillRect(0, 0, s, 22);
      ctx.fillRect(0, s - 22, s, 22);
    });
    this.mars = new THREE.Mesh(
      new THREE.SphereGeometry(20, 64, 48),
      new THREE.MeshStandardMaterial({ map: marsTex, roughness: 0.95 })
    );
    this.mars.position.set(0, 0, -260);
    this.scene.add(this.mars);

    const sun = new THREE.DirectionalLight(0xffe0b8, 3);
    sun.position.set(-40, 18, 30);
    this.scene.add(sun);
    this.scene.add(new THREE.AmbientLight(0x33221a, 0.7));

    // simple spacecraft silhouette
    this.craft = new THREE.Group();
    const busMat = new THREE.MeshStandardMaterial({ color: 0xb8b2a4, roughness: 0.5, metalness: 0.5 });
    const bus = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 0.8, 8), busMat);
    this.craft.add(bus);
    const panelMat = new THREE.MeshStandardMaterial({ color: 0x22406e, roughness: 0.4, metalness: 0.6 });
    [-1, 1].forEach((s) => {
      const p = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.03, 0.7), panelMat);
      p.position.x = s * 1.5;
      this.craft.add(p);
    });
    const dish = new THREE.Mesh(new THREE.ConeGeometry(0.4, 0.25, 16, 1, true), busMat);
    dish.position.set(0, 0.55, 0);
    dish.rotation.x = Math.PI;
    this.craft.add(dish);
    this.craft.position.set(3, -1, -6);
    this.scene.add(this.craft);

    // entry dust / streak particles
    const dustGeo = new THREE.BufferGeometry();
    const n = 900;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 18;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 30;
    }
    dustGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.dust = new THREE.Points(
      dustGeo,
      new THREE.PointsMaterial({ color: 0xffb070, size: 0.06, transparent: true, opacity: 0 })
    );
    this.scene.add(this.dust);

    this.entryLight = new THREE.PointLight(0xff7030, 0, 60);
    this.scene.add(this.entryLight);

    audio.play('space');
  }

  resize(w: number, h: number) {
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  update(dt: number, t: number) {
    this.time += dt;
    const T = this.time;

    // captions
    if (this.beatIdx < CINEMATIC_BEATS.length && T >= CINEMATIC_BEATS[this.beatIdx].at) {
      store.set({ caption: CINEMATIC_BEATS[this.beatIdx] });
      this.beatIdx++;
      setTimeout(() => store.set({ caption: null }), 2600);
    }

    // camera approach: fly toward mars, shake during entry
    const k = Math.min(T / DURATION, 1);
    const ease = k * k * (3 - 2 * k);
    const dist = 120 - ease * 105; // approach mars (at -260 with r=20)
    this.camera.position.set(Math.sin(T * 0.1) * 4, Math.cos(T * 0.08) * 2, this.mars.position.z + dist + 20);
    this.camera.lookAt(this.mars.position);

    // spacecraft drifts then peels away
    this.craft.position.z = -6 - ease * 40;
    this.craft.position.x = 3 + ease * 6;
    this.craft.rotation.z = Math.sin(t * 0.5) * 0.05;
    this.craft.rotation.y += dt * 0.1;

    // entry heating
    if (T > 7 && T < 11) {
      const intensity = 1 - Math.abs(T - 9) / 2;
      (this.dust.material as THREE.PointsMaterial).opacity = intensity * 0.9;
      this.dust.rotation.z += dt * 0.4;
      const shake = intensity * 0.25;
      this.camera.position.x += (Math.random() - 0.5) * shake;
      this.camera.position.y += (Math.random() - 0.5) * shake;
      this.entryLight.intensity = intensity * 40;
      this.entryLight.position.copy(this.camera.position).add(new THREE.Vector3(0, -2, -8));
    } else {
      this.entryLight.intensity = 0;
      (this.dust.material as THREE.PointsMaterial).opacity = Math.max(0, (this.dust.material as THREE.PointsMaterial).opacity - dt);
    }

    this.mars.rotation.y += dt * 0.02;
    this.stars.rotation.y += dt * 0.002;

    this.renderer.render(this.scene, this.camera);

    if (T > DURATION && !this.done) {
      this.done = true;
      store.set({ caption: null });
      store.emit('engine:goto', 'explore');
    }
  }

  dispose() {
    store.set({ caption: null });
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = (m as any).material;
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else mat?.dispose?.();
    });
  }
}
